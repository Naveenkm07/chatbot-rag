# Create requirements.txt for the project
requirements = '''# Core Streamlit and Web Framework
streamlit>=1.28.0
streamlit-chat>=0.1.1

# LangChain and RAG Components
langchain>=0.0.350
langchain-community>=0.0.10
langchain-openai>=0.0.5

# Vector Database and Embeddings
chromadb>=0.4.15
sentence-transformers>=2.2.2
faiss-cpu>=1.7.4

# Document Processing
pypdf>=3.17.0
python-docx>=0.8.11
unstructured>=0.10.30

# LLM Integration
ollama>=0.1.7
groq>=0.4.1
openai>=1.3.0

# Text Processing and NLP
tiktoken>=0.5.1
numpy>=1.24.0
pandas>=2.1.0

# Evaluation and Monitoring (Optional)
arize-phoenix>=1.0.0
phoenix>=1.0.0

# Utility Libraries
python-dotenv>=1.0.0
requests>=2.31.0
urllib3>=2.0.0
pyyaml>=6.0.1
typing-extensions>=4.8.0

# Development and Testing (Optional)
pytest>=7.4.0
black>=23.0.0
flake8>=6.0.0
'''

# Save requirements.txt
with open('requirements.txt', 'w') as f:
    f.write(requirements)

# Create .env template
env_template = '''# Environment Variables Template
# Copy this to .env and fill in your values

# Groq API (Optional - for fast inference)
GROQ_API_KEY=your_groq_api_key_here

# OpenAI API (Optional - for OpenAI models)
OPENAI_API_KEY=your_openai_api_key_here

# Arize Phoenix (Optional - for evaluation)
PHOENIX_API_KEY=your_phoenix_api_key_here

# Streamlit Configuration
STREAMLIT_SERVER_PORT=8501
STREAMLIT_SERVER_ADDRESS=localhost

# Application Settings
APP_NAME="AI Clone RAG Chatbot"
LOG_LEVEL=INFO
'''

with open('.env.template', 'w') as f:
    f.write(env_template)

# Create Docker configuration
dockerfile_content = '''FROM python:3.10-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    curl \\
    software-properties-common \\
    git \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Expose Streamlit port
EXPOSE 8501

# Health check
HEALTHCHECK CMD curl --fail http://localhost:8501/_stcore/health

# Run the application
ENTRYPOINT ["streamlit", "run", "rag_chatbot_complete.py", "--server.port=8501", "--server.address=0.0.0.0"]
'''

with open('Dockerfile', 'w') as f:
    f.write(dockerfile_content)

# Create docker-compose for easy deployment
docker_compose = '''version: '3.8'

services:
  rag-chatbot:
    build: .
    ports:
      - "8501:8501"
    environment:
      - GROQ_API_KEY=${GROQ_API_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - PHOENIX_API_KEY=${PHOENIX_API_KEY}
    volumes:
      - ./chroma_db:/app/chroma_db
      - ./uploads:/app/uploads
    restart: unless-stopped
    
  # Optional: Add Ollama service for local LLM
  ollama:
    image: ollama/ollama:latest
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    restart: unless-stopped
    
volumes:
  ollama_data:
'''

with open('docker-compose.yml', 'w') as f:
    f.write(docker_compose)

# Create setup script
setup_script = '''#!/bin/bash
# Setup script for AI Clone RAG Chatbot

echo "🚀 Setting up AI Clone RAG Chatbot..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first."
    exit 1
fi

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv rag_env

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source rag_env/bin/activate

# Install requirements
echo "📚 Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Copy environment template
if [ ! -f .env ]; then
    echo "⚙️ Creating environment file..."
    cp .env.template .env
    echo "✏️ Please edit .env file with your API keys"
fi

# Check if Ollama is installed (optional)
if ! command -v ollama &> /dev/null; then
    echo "💡 Ollama not found. You can install it from https://ollama.ai/"
    echo "   Or use Groq API for fast inference instead."
fi

echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Edit .env file with your API keys"
echo "2. Run: source rag_env/bin/activate"
echo "3. Run: streamlit run rag_chatbot_complete.py"
echo ""
echo "🐳 Or use Docker:"
echo "1. docker-compose up --build"
echo ""
echo "Happy coding! 🎉"
'''

with open('setup.sh', 'w') as f:
    f.write(setup_script)

# Make setup script executable
import os
os.chmod('setup.sh', 0o755)

# Create README.md
readme_content = '''# 🤖 AI Clone RAG Chatbot

Build Your Own AI Clone with RAG, Prompt Engineering, Vector Databases, and Evaluation using Arize AI.

## 🌟 Features

- **RAG Implementation**: Retrieval Augmented Generation with multiple chunking strategies
- **Prompt Engineering**: Advanced prompting techniques for better responses  
- **Vector Database Management**: Efficient document storage and retrieval
- **Chunking Strategies**: Multiple text processing approaches
- **Llama 3 Integration**: Meta's powerful open-source language model
- **Groq API Support**: Optional fast inference optimization
- **Arize AI Evaluation**: Comprehensive monitoring and evaluation
- **Streamlit Deployment**: User-friendly web interface

## 🚀 Quick Start

### Option 1: Automatic Setup
```bash
chmod +x setup.sh
./setup.sh
source rag_env/bin/activate
streamlit run rag_chatbot_complete.py
```

### Option 2: Manual Setup
```bash
# Create virtual environment
python3 -m venv rag_env
source rag_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup environment variables
cp .env.template .env
# Edit .env with your API keys

# Run the application
streamlit run rag_chatbot_complete.py
```

### Option 3: Docker Deployment
```bash
# Copy environment template
cp .env.template .env
# Edit .env with your API keys

# Run with Docker Compose
docker-compose up --build
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file with the following variables:

```env
# Groq API (Optional - for fast inference)
GROQ_API_KEY=your_groq_api_key_here

# OpenAI API (Optional - for OpenAI models)  
OPENAI_API_KEY=your_openai_api_key_here

# Arize Phoenix (Optional - for evaluation)
PHOENIX_API_KEY=your_phoenix_api_key_here
```

### API Keys Setup

1. **Groq API**: Get free API key from [Groq Console](https://console.groq.com)
2. **Arize Phoenix**: Sign up at [Arize AI](https://arize.com)
3. **OpenAI**: Optional, get from [OpenAI Platform](https://platform.openai.com)

## 📖 Usage Guide

### 1. Upload Documents
- Support for PDF and TXT files
- Multiple file upload capability
- Automatic text extraction and processing

### 2. Configure Chunking Strategy
- **Recursive**: Best for general documents
- **Fixed Size**: Consistent chunk sizes
- **Semantic**: Meaning-based chunking

### 3. Choose Language Model
- **Ollama (Local)**: Free, runs on your machine
- **Groq (Fast)**: Cloud-based, extremely fast inference

### 4. Select Prompt Style
- **Conversational**: Natural chat responses
- **Analytical**: Detailed analysis
- **Creative**: Engaging creative responses

### 5. Start Chatting
- Ask questions about your documents
- View sources for transparency
- Monitor performance with evaluations

## 🏗️ Architecture

```
Documents → Processing → Chunking → Vector DB → Retrieval → LLM → Response
                ↓           ↓          ↓           ↓       ↓        ↓
            Text Extraction  Embeddings  Similarity  Context  Generation  Evaluation
```

## 📊 Skills Gained

- ✅ **Generative AI**: RAG implementation and optimization
- ✅ **Prompt Engineering**: Advanced prompting techniques  
- ✅ **Vector Database Management**: Efficient data storage and retrieval
- ✅ **Chunking Strategies**: Text processing and optimization
- ✅ **Llama 3 Usage**: Integration with Meta's language model
- ✅ **Arize AI Evaluation**: Performance monitoring and analysis
- ✅ **Streamlit Deployment**: Web application development

## 🔧 Advanced Configuration

### Custom Chunking Parameters
```python
# Adjust chunk size and overlap for your documents
chunk_size = 1000  # Characters per chunk
chunk_overlap = 200  # Overlap between chunks
```

### LLM Parameters
```python
# Configure temperature for response creativity
temperature = 0.7  # 0.0 = deterministic, 1.0 = creative
```

### Retrieval Settings
```python
# Number of similar documents to retrieve
k = 5  # Top 5 most similar chunks
```

## 🚀 Deployment Options

### Streamlit Community Cloud
1. Push code to GitHub
2. Connect Streamlit Cloud
3. Add environment variables
4. Deploy automatically

### Docker Container
```bash
# Build and run container
docker build -t rag-chatbot .
docker run -p 8501:8501 rag-chatbot
```

### Local Development
```bash
# Run in development mode
streamlit run rag_chatbot_complete.py --server.runOnSave true
```

## 📈 Evaluation Metrics

Monitor your chatbot's performance with:
- **Response Accuracy**: How correct are the answers?
- **Source Relevance**: Are retrieved documents relevant?
- **Response Time**: How fast are responses generated?
- **User Satisfaction**: Track user feedback and ratings

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is open-source and available under the MIT License.

## 🆘 Support

- 📖 Documentation: Check the code comments
- 🐛 Issues: Report bugs in GitHub Issues  
- 💬 Discussions: Join community discussions
- 📧 Contact: Reach out for enterprise support

## 🎯 Next Steps

After completing this project, consider:
- Fine-tuning models for your specific domain
- Implementing advanced evaluation metrics
- Adding multi-modal capabilities (images, audio)
- Scaling to production with load balancing
- Implementing user authentication and management

---

**Happy Building!** 🎉 Build amazing AI applications with confidence.
'''

with open('README.md', 'w') as f:
    f.write(readme_content)

print("✅ Complete project setup created!")
print("\n📁 Files generated:")
print("  • rag_chatbot_complete.py - Main application")
print("  • requirements.txt - Python dependencies")
print("  • .env.template - Environment variables template")
print("  • Dockerfile - Container configuration")
print("  • docker-compose.yml - Multi-service deployment")
print("  • setup.sh - Automated setup script")
print("  • README.md - Comprehensive documentation")
print("\n🚀 Ready to deploy!")