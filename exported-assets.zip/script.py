import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Rectangle
import numpy as np

# Create a comprehensive RAG architecture diagram
fig, ax = plt.subplots(1, 1, figsize=(14, 10))
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis('off')

# Define colors
primary_color = '#2E86AB'
secondary_color = '#A23B72'
accent_color = '#F18F01'
text_color = '#262A2D'
bg_color = '#F5F5F5'

# Title
ax.text(5, 9.5, 'AI Clone RAG Architecture with Evaluation Pipeline', 
        fontsize=18, fontweight='bold', ha='center', color=text_color)

# Data Sources
data_box = FancyBboxPatch((0.5, 8), 1.5, 0.8, boxstyle="round,pad=0.1", 
                         facecolor=accent_color, edgecolor='black', alpha=0.8)
ax.add_patch(data_box)
ax.text(1.25, 8.4, 'Data Sources', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(1.25, 8.1, '• Documents\n• Web Pages\n• APIs', fontsize=9, ha='center', color='white')

# Document Processing
process_box = FancyBboxPatch((2.5, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                            facecolor=primary_color, edgecolor='black', alpha=0.8)
ax.add_patch(process_box)
ax.text(3.5, 8.4, 'Document Processing', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(3.5, 8.1, '• Text Extraction\n• Chunking Strategies\n• Preprocessing', fontsize=9, ha='center', color='white')

# Vector Database
vector_box = FancyBboxPatch((5.5, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                           facecolor=secondary_color, edgecolor='black', alpha=0.8)
ax.add_patch(vector_box)
ax.text(6.5, 8.4, 'Vector Database', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(6.5, 8.1, '• Embeddings Storage\n• Similarity Search\n• Index Management', fontsize=9, ha='center', color='white')

# Chunking Strategies Detail
chunk_box = FancyBboxPatch((0.5, 6.5), 2.5, 1, boxstyle="round,pad=0.1", 
                          facecolor='#E8F4F8', edgecolor=primary_color, alpha=0.9)
ax.add_patch(chunk_box)
ax.text(1.75, 7.2, 'Chunking Strategies', fontsize=11, fontweight='bold', ha='center', color=text_color)
ax.text(1.75, 6.8, '• Fixed-size Chunking\n• Semantic Chunking\n• Recursive Chunking\n• Sentence-based', 
        fontsize=9, ha='center', color=text_color)

# Retrieval System
retrieval_box = FancyBboxPatch((3.5, 6.5), 2.5, 1, boxstyle="round,pad=0.1", 
                              facecolor='#F8E8F4', edgecolor=secondary_color, alpha=0.9)
ax.add_patch(retrieval_box)
ax.text(4.75, 7.2, 'Retrieval System', fontsize=11, fontweight='bold', ha='center', color=text_color)
ax.text(4.75, 6.8, '• Query Processing\n• Similarity Matching\n• Context Selection\n• Reranking', 
        fontsize=9, ha='center', color=text_color)

# LLM Integration
llm_box = FancyBboxPatch((6.5, 6.5), 2.5, 1, boxstyle="round,pad=0.1", 
                        facecolor='#FFF8E8', edgecolor=accent_color, alpha=0.9)
ax.add_patch(llm_box)
ax.text(7.75, 7.2, 'LLM Integration', fontsize=11, fontweight='bold', ha='center', color=text_color)
ax.text(7.75, 6.8, '• Llama 3 Models\n• Groq API (Optional)\n• Prompt Engineering\n• Response Generation', 
        fontsize=9, ha='center', color=text_color)

# User Interface
ui_box = FancyBboxPatch((0.5, 4.8), 2, 1, boxstyle="round,pad=0.1", 
                       facecolor=primary_color, edgecolor='black', alpha=0.8)
ax.add_patch(ui_box)
ax.text(1.5, 5.5, 'User Interface', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(1.5, 5.1, '• Streamlit App\n• Chat Interface\n• File Upload\n• Real-time Responses', 
        fontsize=9, ha='center', color='white')

# Evaluation System
eval_box = FancyBboxPatch((3, 4.8), 2.5, 1, boxstyle="round,pad=0.1", 
                         facecolor=secondary_color, edgecolor='black', alpha=0.8)
ax.add_patch(eval_box)
ax.text(4.25, 5.5, 'Evaluation System', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(4.25, 5.1, '• Arize Phoenix\n• Performance Metrics\n• Trace Analysis\n• Model Monitoring', 
        fontsize=9, ha='center', color='white')

# Deployment
deploy_box = FancyBboxPatch((6, 4.8), 2.5, 1, boxstyle="round,pad=0.1", 
                           facecolor=accent_color, edgecolor='black', alpha=0.8)
ax.add_patch(deploy_box)
ax.text(7.25, 5.5, 'Deployment', fontsize=11, fontweight='bold', ha='center', color='white')
ax.text(7.25, 5.1, '• Streamlit Cloud\n• Docker Container\n• Environment Setup\n• API Integration', 
        fontsize=9, ha='center', color='white')

# Prompt Engineering Detail
prompt_box = FancyBboxPatch((1, 3), 3.5, 1.2, boxstyle="round,pad=0.1", 
                           facecolor='#F0F8FF', edgecolor='#4169E1', alpha=0.9)
ax.add_patch(prompt_box)
ax.text(2.75, 3.8, 'Prompt Engineering Techniques', fontsize=11, fontweight='bold', ha='center', color=text_color)
ax.text(2.75, 3.3, '• Zero-shot & Few-shot Prompting\n• Chain-of-Thought Reasoning\n• Context Enhancement\n• Response Optimization\n• Template Management', 
        fontsize=9, ha='center', color=text_color)

# Performance Optimization
perf_box = FancyBboxPatch((5, 3), 3.5, 1.2, boxstyle="round,pad=0.1", 
                         facecolor='#FFF0F5', edgecolor='#DC143C', alpha=0.9)
ax.add_patch(perf_box)
ax.text(6.75, 3.8, 'Performance Optimization', fontsize=11, fontweight='bold', ha='center', color=text_color)
ax.text(6.75, 3.3, '• Groq Fast Inference\n• Caching Strategies\n• Load Balancing\n• Memory Management\n• Response Streaming', 
        fontsize=9, ha='center', color=text_color)

# Skills Gained Box
skills_box = FancyBboxPatch((1.5, 1), 6, 1.5, boxstyle="round,pad=0.15", 
                           facecolor='#E6F3FF', edgecolor='#0066CC', alpha=0.9, linewidth=2)
ax.add_patch(skills_box)
ax.text(4.5, 2.2, 'Skills Gained from This Project', fontsize=14, fontweight='bold', ha='center', color='#0066CC')
ax.text(4.5, 1.6, '• Generative AI & RAG Implementation  • Prompt Engineering & Optimization\n• Vector Database Management  • Chunking Strategies & Text Processing\n• Llama 3 Integration & Usage  • Arize AI Evaluation & Monitoring\n• Streamlit Deployment & UI Development', 
        fontsize=10, ha='center', color=text_color, linespacing=1.5)

# Add arrows to show flow
arrow_props = dict(arrowstyle='->', lw=2, color='#333333')

# Horizontal arrows
ax.annotate('', xy=(2.4, 8.4), xytext=(2.1, 8.4), arrowprops=arrow_props)
ax.annotate('', xy=(5.4, 8.4), xytext=(4.6, 8.4), arrowprops=arrow_props)

# Vertical arrows
ax.annotate('', xy=(1.5, 5.9), xytext=(1.5, 6.4), arrowprops=arrow_props)
ax.annotate('', xy=(4.25, 5.9), xytext=(4.25, 6.4), arrowprops=arrow_props)
ax.annotate('', xy=(7.25, 5.9), xytext=(7.25, 6.4), arrowprops=arrow_props)

plt.tight_layout()
plt.savefig('rag_architecture_diagram.png', dpi=300, bbox_inches='tight', facecolor='white')
plt.show()

print("RAG Architecture diagram created successfully!")