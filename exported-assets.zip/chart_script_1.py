import plotly.graph_objects as go
import pandas as pd

# Create the data
data = {
    "weeks": [1, 2, 3, 4, 5, 6, 7, 8],
    "response_accuracy": [65, 72, 75, 82, 84, 88, 90, 92],
    "retrieval_relevance": [58, 68, 70, 78, 80, 85, 87, 89],
    "response_time": [4.5, 3.8, 3.6, 2.9, 2.7, 2.1, 1.8, 1.2],
    "user_satisfaction": [3.2, 3.6, 3.7, 4.1, 4.2, 4.4, 4.5, 4.6]
}

# Normalize all metrics to 0-100 scale for consistent visualization
response_accuracy_norm = data["response_accuracy"]
retrieval_relevance_norm = data["retrieval_relevance"]

# Response time: normalize to 0-100 where 100 is best performance (lowest time)
min_time = min(data["response_time"])
max_time = max(data["response_time"])
response_time_norm = [(max_time - time) / (max_time - min_time) * 100 for time in data["response_time"]]

# User satisfaction: normalize 1-5 scale to 0-100
min_sat = 1
max_sat = 5
user_satisfaction_norm = [(rating - min_sat) / (max_sat - min_sat) * 100 for rating in data["user_satisfaction"]]

# Create the figure
fig = go.Figure()

# Brand colors - using stronger colors for better visibility
colors = ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F']

# Add traces for each metric with detailed hover information
fig.add_trace(go.Scatter(
    x=data["weeks"],
    y=response_accuracy_norm,
    mode='lines+markers',
    name='Resp Accuracy',
    line=dict(color=colors[0], width=3),
    marker=dict(size=8),
    cliponaxis=False,
    hovertemplate='Week %{x}<br>Accuracy: %{customdata}%<extra></extra>',
    customdata=data["response_accuracy"]
))

fig.add_trace(go.Scatter(
    x=data["weeks"],
    y=retrieval_relevance_norm,
    mode='lines+markers',
    name='Retr Relevance',
    line=dict(color=colors[1], width=3),
    marker=dict(size=8),
    cliponaxis=False,
    hovertemplate='Week %{x}<br>Relevance: %{customdata}%<extra></extra>',
    customdata=data["retrieval_relevance"]
))

fig.add_trace(go.Scatter(
    x=data["weeks"],
    y=response_time_norm,
    mode='lines+markers',
    name='Resp Time',
    line=dict(color=colors[2], width=3),
    marker=dict(size=8),
    cliponaxis=False,
    hovertemplate='Week %{x}<br>Time: %{customdata}s<extra></extra>',
    customdata=data["response_time"]
))

fig.add_trace(go.Scatter(
    x=data["weeks"],
    y=user_satisfaction_norm,
    mode='lines+markers',
    name='User Satisf',
    line=dict(color=colors[3], width=3),
    marker=dict(size=8),
    cliponaxis=False,
    hovertemplate='Week %{x}<br>Rating: %{customdata}/5<extra></extra>',
    customdata=data["user_satisfaction"]
))

# Update layout
fig.update_layout(
    title='RAG System Performance Over Time',
    xaxis_title='Week',
    yaxis_title='Normalized Score',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update axes
fig.update_xaxes(
    tickmode='linear',
    tick0=1,
    dtick=1,
    range=[0.5, 8.5]
)

fig.update_yaxes(
    range=[0, 100],
    tickformat='.0f'
)

# Save the chart
fig.write_image('rag_metrics_dashboard.png', width=800, height=600)