# 🤖 AI Clone RAG Chatbot

Build Your Own AI Clone with RAG, Prompt Engineering, Vector Databases, and Evaluation using Arize AI.

## 🌟 Features

- **RAG Implementation**: Retrieval Augmented Generation with multiple chunking strategies
- **Prompt Engineering**: Advanced prompting techniques for better responses  
- **Vector Database Management**: Efficient document storage and retrieval
- **Chunking Strategies**: Multiple text processing approaches
- **Llama 3 Integration**: Meta's powerful open-source language model
- **Groq API Support**: Optional fast inference optimization
- **Arize AI Evaluation**: Comprehensive monitoring and evaluation
- **Streamlit Deployment**: User-friendly web interface

## 🚀 Quick Start

### Option 1: Automatic Setup
```bash
chmod +x setup.sh
./setup.sh
source rag_env/bin/activate
streamlit run rag_chatbot_complete.py
```

### Option 2: Manual Setup
```bash
# Create virtual environment
python3 -m venv rag_env
source rag_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup environment variables
cp .env.template .env
# Edit .env with your API keys

# Run the application
streamlit run rag_chatbot_complete.py
```

### Option 3: Docker Deployment
```bash
# Copy environment template
cp .env.template .env
# Edit .env with your API keys

# Run with Docker Compose
docker-compose up --build
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file with the following variables:

```env
# Groq API (Optional - for fast inference)
GROQ_API_KEY=your_groq_api_key_here

# OpenAI API (Optional - for OpenAI models)  
OPENAI_API_KEY=your_openai_api_key_here

# Arize Phoenix (Optional - for evaluation)
PHOENIX_API_KEY=your_phoenix_api_key_here
```

### API Keys Setup

1. **Groq API**: Get free API key from [Groq Console](https://console.groq.com)
2. **Arize Phoenix**: Sign up at [Arize AI](https://arize.com)
3. **OpenAI**: Optional, get from [OpenAI Platform](https://platform.openai.com)

## 📖 Usage Guide

### 1. Upload Documents
- Support for PDF and TXT files
- Multiple file upload capability
- Automatic text extraction and processing

### 2. Configure Chunking Strategy
- **Recursive**: Best for general documents
- **Fixed Size**: Consistent chunk sizes
- **Semantic**: Meaning-based chunking

### 3. Choose Language Model
- **Ollama (Local)**: Free, runs on your machine
- **Groq (Fast)**: Cloud-based, extremely fast inference

### 4. Select Prompt Style
- **Conversational**: Natural chat responses
- **Analytical**: Detailed analysis
- **Creative**: Engaging creative responses

### 5. Start Chatting
- Ask questions about your documents
- View sources for transparency
- Monitor performance with evaluations

## 🏗️ Architecture

```
Documents → Processing → Chunking → Vector DB → Retrieval → LLM → Response
                ↓           ↓          ↓           ↓       ↓        ↓
            Text Extraction  Embeddings  Similarity  Context  Generation  Evaluation
```

## 📊 Skills Gained

- ✅ **Generative AI**: RAG implementation and optimization
- ✅ **Prompt Engineering**: Advanced prompting techniques  
- ✅ **Vector Database Management**: Efficient data storage and retrieval
- ✅ **Chunking Strategies**: Text processing and optimization
- ✅ **Llama 3 Usage**: Integration with Meta's language model
- ✅ **Arize AI Evaluation**: Performance monitoring and analysis
- ✅ **Streamlit Deployment**: Web application development

## 🔧 Advanced Configuration

### Custom Chunking Parameters
```python
# Adjust chunk size and overlap for your documents
chunk_size = 1000  # Characters per chunk
chunk_overlap = 200  # Overlap between chunks
```

### LLM Parameters
```python
# Configure temperature for response creativity
temperature = 0.7  # 0.0 = deterministic, 1.0 = creative
```

### Retrieval Settings
```python
# Number of similar documents to retrieve
k = 5  # Top 5 most similar chunks
```

## 🚀 Deployment Options

### Streamlit Community Cloud
1. Push code to GitHub
2. Connect Streamlit Cloud
3. Add environment variables
4. Deploy automatically

### Docker Container
```bash
# Build and run container
docker build -t rag-chatbot .
docker run -p 8501:8501 rag-chatbot
```

### Local Development
```bash
# Run in development mode
streamlit run rag_chatbot_complete.py --server.runOnSave true
```

## 📈 Evaluation Metrics

Monitor your chatbot's performance with:
- **Response Accuracy**: How correct are the answers?
- **Source Relevance**: Are retrieved documents relevant?
- **Response Time**: How fast are responses generated?
- **User Satisfaction**: Track user feedback and ratings

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is open-source and available under the MIT License.

## 🆘 Support

- 📖 Documentation: Check the code comments
- 🐛 Issues: Report bugs in GitHub Issues  
- 💬 Discussions: Join community discussions
- 📧 Contact: Reach out for enterprise support

## 🎯 Next Steps

After completing this project, consider:
- Fine-tuning models for your specific domain
- Implementing advanced evaluation metrics
- Adding multi-modal capabilities (images, audio)
- Scaling to production with load balancing
- Implementing user authentication and management

---

**Happy Building!** 🎉 Build amazing AI applications with confidence.
