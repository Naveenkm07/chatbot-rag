
# AI Clone RAG Implementation with Streamlit
# This is a complete implementation guide for building a RAG chatbot

import streamlit as st
import os
from typing import List, Dict, Any
import logging
from datetime import datetime

# Core libraries for RAG
from langchain.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.llms import Ollama
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory

# Optional: Groq API for fast inference
try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False

# Optional: Arize Phoenix for evaluation
try:
    import phoenix as px
    from phoenix.trace.langchain import LangChainInstrumentor
    PHOENIX_AVAILABLE = True
except ImportError:
    PHOENIX_AVAILABLE = False

class RAGChatbot:
    """Complete RAG Chatbot Implementation"""

    def __init__(self):
        self.setup_logging()
        self.initialize_components()

    def setup_logging(self):
        """Setup logging for debugging and monitoring"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def initialize_components(self):
        """Initialize RAG pipeline components"""
        self.embeddings = None
        self.vectorstore = None
        self.llm = None
        self.qa_chain = None
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )

    def load_documents(self, uploaded_files) -> List[Dict]:
        """Load and process uploaded documents"""
        documents = []

        for uploaded_file in uploaded_files:
            try:
                # Save uploaded file temporarily
                with open(f"temp_{uploaded_file.name}", "wb") as f:
                    f.write(uploaded_file.getbuffer())

                # Load document based on file type
                if uploaded_file.name.endswith('.pdf'):
                    loader = PyPDFLoader(f"temp_{uploaded_file.name}")
                elif uploaded_file.name.endswith('.txt'):
                    loader = TextLoader(f"temp_{uploaded_file.name}")
                else:
                    st.error(f"Unsupported file type: {uploaded_file.name}")
                    continue

                docs = loader.load()
                documents.extend(docs)

                # Clean up temporary file
                os.remove(f"temp_{uploaded_file.name}")

                self.logger.info(f"Loaded {len(docs)} documents from {uploaded_file.name}")

            except Exception as e:
                st.error(f"Error loading {uploaded_file.name}: {str(e)}")
                self.logger.error(f"Error loading {uploaded_file.name}: {str(e)}")

        return documents

    def setup_chunking_strategy(self, strategy: str, chunk_size: int = 1000, chunk_overlap: int = 200):
        """Setup different chunking strategies"""

        if strategy == "recursive":
            return RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separators=["\n\n", "\n", " ", ""]
            )
        elif strategy == "fixed_size":
            return RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separators=[" "]
            )
        elif strategy == "semantic":
            # For semantic chunking, you'd implement custom logic
            # This is a simplified version
            return RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                separators=["\n\n", "\n", ".", " "]
            )
        else:
            return RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap
            )

    def create_vector_database(self, documents, chunking_strategy="recursive"):
        """Create vector database from documents"""
        try:
            # Setup text splitter based on strategy
            text_splitter = self.setup_chunking_strategy(chunking_strategy)

            # Split documents into chunks
            texts = text_splitter.split_documents(documents)

            st.info(f"Created {len(texts)} text chunks using {chunking_strategy} strategy")

            # Initialize embeddings
            self.embeddings = HuggingFaceEmbeddings(
                model_name="sentence-transformers/all-MiniLM-L6-v2"
            )

            # Create vector store
            self.vectorstore = Chroma.from_documents(
                documents=texts,
                embedding=self.embeddings,
                persist_directory="./chroma_db"
            )

            self.logger.info("Vector database created successfully")
            return True

        except Exception as e:
            st.error(f"Error creating vector database: {str(e)}")
            self.logger.error(f"Error creating vector database: {str(e)}")
            return False

    def setup_llm(self, model_choice: str, api_key: str = None):
        """Setup LLM based on user choice"""
        try:
            if model_choice == "Groq (Fast)" and GROQ_AVAILABLE and api_key:
                # Using Groq for fast inference
                self.llm = Groq(
                    api_key=api_key,
                    model_name="llama3-70b-8192"  # or llama3-8b-8192 for faster responses
                )
                st.success("Groq LLM initialized for fast inference!")

            elif model_choice == "Ollama (Local)":
                # Using local Ollama
                self.llm = Ollama(
                    model="llama3",
                    temperature=0.7
                )
                st.success("Local Ollama LLM initialized!")

            else:
                st.error("Please select a valid LLM option and provide required credentials")
                return False

            self.logger.info(f"LLM initialized: {model_choice}")
            return True

        except Exception as e:
            st.error(f"Error setting up LLM: {str(e)}")
            self.logger.error(f"Error setting up LLM: {str(e)}")
            return False

    def create_prompt_template(self, prompt_style: str = "conversational"):
        """Create optimized prompt templates for different use cases"""

        if prompt_style == "conversational":
            template = """
            You are an AI assistant designed to have natural conversations based on the provided context.
            Use the following pieces of context to answer the question. If you don't know the answer,
            just say that you don't know, don't try to make up an answer.

            Context: {context}

            Chat History: {chat_history}

            Human: {question}

            Assistant: I'll help you with that based on the information provided. """

        elif prompt_style == "analytical":
            template = """
            You are an expert analyst. Analyze the following context carefully and provide a detailed,
            well-structured response to the question. Support your answer with evidence from the context.

            Context: {context}

            Question: {question}

            Analysis: """

        elif prompt_style == "creative":
            template = """
            You are a creative AI assistant. Use the provided context as inspiration to craft an
            engaging and informative response. Be creative but stay grounded in the facts.

            Context: {context}

            Question: {question}

            Creative Response: """

        else:  # default
            template = """
            Use the following pieces of context to answer the question at the end.
            If you don't know the answer, just say that you don't know.

            {context}

            Question: {question}
            Answer: """

        return PromptTemplate(
            template=template,
            input_variables=["context", "question", "chat_history"] if "chat_history" in template else ["context", "question"]
        )

    def setup_qa_chain(self, prompt_style: str = "conversational"):
        """Setup the QA chain with retrieval"""
        try:
            if not self.vectorstore or not self.llm:
                st.error("Please initialize vector database and LLM first")
                return False

            # Create retriever
            retriever = self.vectorstore.as_retriever(
                search_type="similarity",
                search_kwargs={"k": 5}  # Retrieve top 5 similar chunks
            )

            # Create prompt template
            prompt = self.create_prompt_template(prompt_style)

            # Create QA chain
            self.qa_chain = RetrievalQA.from_chain_type(
                llm=self.llm,
                chain_type="stuff",
                retriever=retriever,
                chain_type_kwargs={"prompt": prompt},
                return_source_documents=True
            )

            self.logger.info("QA chain setup completed")
            return True

        except Exception as e:
            st.error(f"Error setting up QA chain: {str(e)}")
            self.logger.error(f"Error setting up QA chain: {str(e)}")
            return False

    def get_response(self, query: str) -> Dict[str, Any]:
        """Get response from the RAG system"""
        try:
            if not self.qa_chain:
                return {"error": "QA chain not initialized"}

            # Get response from QA chain
            result = self.qa_chain({"query": query})

            # Extract source documents for transparency
            sources = []
            if "source_documents" in result:
                for doc in result["source_documents"]:
                    sources.append({
                        "content": doc.page_content[:200] + "...",
                        "source": doc.metadata.get("source", "Unknown")
                    })

            return {
                "answer": result["result"],
                "sources": sources,
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            self.logger.error(f"Error getting response: {str(e)}")
            return {"error": f"Error generating response: {str(e)}"}

# Streamlit App Implementation
def main():
    """Main Streamlit application"""

    st.set_page_config(
        page_title="AI Clone RAG Chatbot",
        page_icon="🤖",
        layout="wide"
    )

    st.title("🤖 AI Clone RAG Chatbot")
    st.markdown("Build your own AI chatbot with RAG, prompt engineering, and evaluation!")

    # Initialize session state
    if 'chatbot' not in st.session_state:
        st.session_state.chatbot = RAGChatbot()

    if 'messages' not in st.session_state:
        st.session_state.messages = []

    if 'setup_complete' not in st.session_state:
        st.session_state.setup_complete = False

    # Sidebar for configuration
    with st.sidebar:
        st.header("⚙️ Configuration")

        # Document upload
        st.subheader("📁 Document Upload")
        uploaded_files = st.file_uploader(
            "Upload documents",
            type=['pdf', 'txt'],
            accept_multiple_files=True
        )

        # Chunking strategy selection
        st.subheader("📄 Chunking Strategy")
        chunking_strategy = st.selectbox(
            "Choose chunking method",
            ["recursive", "fixed_size", "semantic"]
        )

        chunk_size = st.slider("Chunk Size", 500, 2000, 1000)
        chunk_overlap = st.slider("Chunk Overlap", 0, 500, 200)

        # LLM selection
        st.subheader("🧠 Language Model")
        model_choice = st.selectbox(
            "Choose LLM",
            ["Ollama (Local)", "Groq (Fast)"]
        )

        groq_api_key = None
        if model_choice == "Groq (Fast)":
            groq_api_key = st.text_input("Groq API Key", type="password")

        # Prompt style selection
        st.subheader("💬 Prompt Engineering")
        prompt_style = st.selectbox(
            "Prompt Style",
            ["conversational", "analytical", "creative"]
        )

        # Setup button
        if st.button("🚀 Setup RAG System"):
            if uploaded_files:
                with st.spinner("Setting up RAG system..."):
                    # Load documents
                    documents = st.session_state.chatbot.load_documents(uploaded_files)

                    if documents:
                        # Create vector database
                        if st.session_state.chatbot.create_vector_database(documents, chunking_strategy):
                            # Setup LLM
                            if st.session_state.chatbot.setup_llm(model_choice, groq_api_key):
                                # Setup QA chain
                                if st.session_state.chatbot.setup_qa_chain(prompt_style):
                                    st.session_state.setup_complete = True
                                    st.success("🎉 RAG system setup complete!")
            else:
                st.error("Please upload documents first!")

        # Evaluation section
        if PHOENIX_AVAILABLE:
            st.subheader("📊 Evaluation (Arize Phoenix)")
            if st.button("Start Phoenix Monitoring"):
                session = px.launch_app()
                LangChainInstrumentor().instrument()
                st.success("Phoenix monitoring started!")

    # Main chat interface
    if st.session_state.setup_complete:
        st.header("💭 Chat with your documents")

        # Display chat history
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.write(message["content"])

                if "sources" in message:
                    with st.expander("📚 Sources"):
                        for i, source in enumerate(message["sources"]):
                            st.write(f"**Source {i+1}:** {source['source']}")
                            st.write(f"*Content:* {source['content']}")

        # Chat input
        if prompt := st.chat_input("Ask a question about your documents"):
            # Add user message
            st.session_state.messages.append({"role": "user", "content": prompt})

            with st.chat_message("user"):
                st.write(prompt)

            # Get AI response
            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    response = st.session_state.chatbot.get_response(prompt)

                    if "error" in response:
                        st.error(response["error"])
                    else:
                        st.write(response["answer"])

                        # Add assistant message with sources
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": response["answer"],
                            "sources": response["sources"]
                        })

                        # Show sources
                        if response["sources"]:
                            with st.expander("📚 Sources"):
                                for i, source in enumerate(response["sources"]):
                                    st.write(f"**Source {i+1}:** {source['source']}")
                                    st.write(f"*Content:* {source['content']}")

    else:
        st.info("👈 Please configure and setup your RAG system using the sidebar to start chatting!")

        # Display setup instructions
        st.header("🚀 Quick Start Guide")

        col1, col2 = st.columns(2)

        with col1:
            st.subheader("1️⃣ Upload Documents")
            st.write("• Upload PDF or text files")
            st.write("• Multiple files supported")
            st.write("• Documents will be processed and indexed")

            st.subheader("2️⃣ Configure Chunking")
            st.write("• Choose chunking strategy")
            st.write("• Adjust chunk size and overlap")
            st.write("• Optimize for your document type")

        with col2:
            st.subheader("3️⃣ Select LLM")
            st.write("• Ollama for local deployment")
            st.write("• Groq for fast cloud inference")
            st.write("• Configure API keys if needed")

            st.subheader("4️⃣ Setup & Chat")
            st.write("• Click 'Setup RAG System'")
            st.write("• Wait for processing to complete")
            st.write("• Start asking questions!")

if __name__ == "__main__":
    main()
