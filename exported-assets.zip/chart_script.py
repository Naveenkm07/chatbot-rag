import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# Create the chunking strategies data with normalized processing speed
data = {
    "strategy": ["Fixed-size", "Recursive", "Semantic", "Sentence"],
    "retrieval_accuracy": [72, 85, 92, 68],
    "response_quality": [75, 88, 94, 70],
    "processing_speed_raw": [45, 38, 25, 52],  # chunks/sec
    "memory_usage": [85, 78, 92, 65]  # MB
}

df = pd.DataFrame(data)

# Normalize processing speed to 0-100 scale (invert since higher speed is better)
max_speed = df['processing_speed_raw'].max()
df['processing_speed'] = (df['processing_speed_raw'] / max_speed) * 100

# Create the grouped bar chart
fig = go.Figure()

# Define colors from the brand palette
colors = ['#1FB8CD', '#FFC185', '#ECEBD5', '#5D878F']

# Add bars for each metric with hover info showing actual values
fig.add_trace(go.Bar(
    name='Retrieval Acc',
    x=df['strategy'],
    y=df['retrieval_accuracy'],
    marker_color=colors[0],
    cliponaxis=False,
    hovertemplate='%{x}<br>Retrieval Acc: %{y}%<extra></extra>'
))

fig.add_trace(go.Bar(
    name='Response Qual',
    x=df['strategy'],
    y=df['response_quality'],
    marker_color=colors[1],
    cliponaxis=False,
    hovertemplate='%{x}<br>Response Qual: %{y}%<extra></extra>'
))

fig.add_trace(go.Bar(
    name='Proc Speed',
    x=df['strategy'],
    y=df['processing_speed'],
    marker_color=colors[2],
    cliponaxis=False,
    customdata=df['processing_speed_raw'],
    hovertemplate='%{x}<br>Proc Speed: %{customdata} chunks/sec<extra></extra>'
))

fig.add_trace(go.Bar(
    name='Memory Usage',
    x=df['strategy'],
    y=df['memory_usage'],
    marker_color=colors[3],
    cliponaxis=False,
    hovertemplate='%{x}<br>Memory Usage: %{y} MB<extra></extra>'
))

# Update layout
fig.update_layout(
    title='RAG Chunking Performance Comparison',
    xaxis_title='Chunking Strategy',
    yaxis_title='Performance Score',
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Save the chart
fig.write_image("rag_performance_comparison.png")